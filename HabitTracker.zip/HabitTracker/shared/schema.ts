import { pgTable, text, serial, integer, date, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Define the valid categories for habits
export const HABIT_CATEGORIES = ['health', 'productivity', 'learning', 'personal'] as const;
export type HabitCategory = typeof HABIT_CATEGORIES[number];

// Define the frequency options for habits
export const FREQUENCY_TYPES = ['daily', 'weekdays', 'weekends', 'custom'] as const;
export type FrequencyType = typeof FREQUENCY_TYPES[number];

// Habit table definition
export const habits = pgTable("habits", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  category: text("category").$type<HabitCategory>().notNull(),
  frequencyType: text("frequency_type").$type<FrequencyType>().notNull(),
  customDays: jsonb("custom_days").$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  userId: integer("user_id").references(() => users.id),
});

export const insertHabitSchema = createInsertSchema(habits)
  .omit({ id: true, createdAt: true })
  .extend({
    category: z.enum(HABIT_CATEGORIES),
    frequencyType: z.enum(FREQUENCY_TYPES),
    customDays: z.array(z.string()).optional(),
  });

export type Habit = typeof habits.$inferSelect;
export type InsertHabit = z.infer<typeof insertHabitSchema>;

// HabitLog table to track completions
export const habitLogs = pgTable("habit_logs", {
  id: serial("id").primaryKey(),
  habitId: integer("habit_id").notNull().references(() => habits.id),
  date: date("date").notNull(),
  completed: boolean("completed").notNull(),
  userId: integer("user_id").references(() => users.id),
});

export const insertHabitLogSchema = createInsertSchema(habitLogs)
  .omit({ id: true });

export type HabitLog = typeof habitLogs.$inferSelect;
export type InsertHabitLog = z.infer<typeof insertHabitLogSchema>;

// Create a schema for updating habit logs (toggling completion)
export const updateHabitLogSchema = z.object({
  completed: z.boolean(),
});

export type UpdateHabitLog = z.infer<typeof updateHabitLogSchema>;
