import { 
  users, habits, habitLogs, 
  type User, type InsertUser, 
  type Habit, type InsertHabit, 
  type HabitLog, type InsertHabitLog,
  type UpdateHabitLog
} from "@shared/schema";
import { format } from "date-fns";

// Interface for all storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Habit operations
  getHabits(userId?: number): Promise<Habit[]>;
  getHabitById(id: number): Promise<Habit | undefined>;
  createHabit(habit: InsertHabit): Promise<Habit>;
  updateHabit(id: number, habit: Partial<InsertHabit>): Promise<Habit | undefined>;
  deleteHabit(id: number): Promise<boolean>;

  // HabitLog operations
  getHabitLogsForDate(date: Date, userId?: number): Promise<HabitLog[]>;
  getHabitLogsInRange(startDate: Date, endDate: Date, userId?: number): Promise<HabitLog[]>;
  getHabitLogsForHabit(habitId: number): Promise<HabitLog[]>;
  createHabitLog(log: InsertHabitLog): Promise<HabitLog>;
  updateHabitLog(habitId: number, date: Date, update: UpdateHabitLog): Promise<HabitLog | undefined>;
  getHabitLog(habitId: number, date: Date): Promise<HabitLog | undefined>;

  // Stats operations
  getCompletionRate(userId?: number, days?: number): Promise<number>;
  getCurrentStreak(habitId: number): Promise<number>;
  getTodayStats(userId?: number): Promise<{ total: number; completed: number }>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private habits: Map<number, Habit>;
  private habitLogs: Map<string, HabitLog>;
  private currentUserId: number;
  private currentHabitId: number;
  private currentHabitLogId: number;

  constructor() {
    this.users = new Map();
    this.habits = new Map();
    this.habitLogs = new Map();
    this.currentUserId = 1;
    this.currentHabitId = 1;
    this.currentHabitLogId = 1;

    // Add a default user for development
    this.createUser({ username: "demo", password: "demo" });
  }

  // Helper method to generate a key for habit logs
  private getHabitLogKey(habitId: number, date: Date): string {
    return `${habitId}-${format(date, 'yyyy-MM-dd')}`;
  }

  // User Operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Habit Operations
  async getHabits(userId?: number): Promise<Habit[]> {
    return Array.from(this.habits.values())
      .filter((habit) => userId ? habit.userId === userId : true);
  }

  async getHabitById(id: number): Promise<Habit | undefined> {
    return this.habits.get(id);
  }

  async createHabit(insertHabit: InsertHabit): Promise<Habit> {
    const id = this.currentHabitId++;
    const now = new Date();
    const habit: Habit = { 
      ...insertHabit, 
      id, 
      createdAt: now
    };
    this.habits.set(id, habit);
    return habit;
  }

  async updateHabit(id: number, updates: Partial<InsertHabit>): Promise<Habit | undefined> {
    const habit = this.habits.get(id);
    if (!habit) return undefined;

    const updatedHabit = { ...habit, ...updates };
    this.habits.set(id, updatedHabit);
    return updatedHabit;
  }

  async deleteHabit(id: number): Promise<boolean> {
    return this.habits.delete(id);
  }

  // HabitLog Operations
  async getHabitLogsForDate(date: Date, userId?: number): Promise<HabitLog[]> {
    const dateString = format(date, 'yyyy-MM-dd');
    return Array.from(this.habitLogs.values())
      .filter((log) => {
        const logDate = format(new Date(log.date), 'yyyy-MM-dd');
        const belongsToUser = userId ? log.userId === userId : true;
        return logDate === dateString && belongsToUser;
      });
  }

  async getHabitLogsInRange(startDate: Date, endDate: Date, userId?: number): Promise<HabitLog[]> {
    const start = startDate.getTime();
    const end = endDate.getTime();
    return Array.from(this.habitLogs.values())
      .filter((log) => {
        const logDate = new Date(log.date).getTime();
        const belongsToUser = userId ? log.userId === userId : true;
        return logDate >= start && logDate <= end && belongsToUser;
      });
  }

  async getHabitLogsForHabit(habitId: number): Promise<HabitLog[]> {
    return Array.from(this.habitLogs.values())
      .filter((log) => log.habitId === habitId);
  }

  async getHabitLog(habitId: number, date: Date): Promise<HabitLog | undefined> {
    const key = this.getHabitLogKey(habitId, date);
    return this.habitLogs.get(key);
  }

  async createHabitLog(insertLog: InsertHabitLog): Promise<HabitLog> {
    const id = this.currentHabitLogId++;
    const log: HabitLog = { ...insertLog, id };
    const key = this.getHabitLogKey(log.habitId, new Date(log.date));
    this.habitLogs.set(key, log);
    return log;
  }

  async updateHabitLog(habitId: number, date: Date, update: UpdateHabitLog): Promise<HabitLog | undefined> {
    const key = this.getHabitLogKey(habitId, date);
    const log = this.habitLogs.get(key);
    if (!log) return undefined;

    const updatedLog = { ...log, ...update };
    this.habitLogs.set(key, updatedLog);
    return updatedLog;
  }

  // Statistics Operations
  async getCompletionRate(userId?: number, days = 7): Promise<number> {
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(endDate.getDate() - days);

    const logs = await this.getHabitLogsInRange(startDate, endDate, userId);
    if (logs.length === 0) return 0;

    const completedCount = logs.filter(log => log.completed).length;
    return Math.round((completedCount / logs.length) * 100);
  }

  async getCurrentStreak(habitId: number): Promise<number> {
    const logs = await this.getHabitLogsForHabit(habitId);
    if (logs.length === 0) return 0;

    // Sort logs by date in descending order
    const sortedLogs = logs.sort((a, b) => {
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    });

    let streak = 0;
    let currentDate = new Date();
    
    // Start from today and go backwards
    while (true) {
      const dateStr = format(currentDate, 'yyyy-MM-dd');
      const log = sortedLogs.find(l => format(new Date(l.date), 'yyyy-MM-dd') === dateStr);
      
      // If no log for this date or the habit was not completed, break the streak
      if (!log || !log.completed) break;
      
      streak++;
      // Move to the previous day
      currentDate.setDate(currentDate.getDate() - 1);
    }

    return streak;
  }

  async getTodayStats(userId?: number): Promise<{ total: number; completed: number }> {
    const today = new Date();
    const logs = await this.getHabitLogsForDate(today, userId);
    
    return {
      total: logs.length,
      completed: logs.filter(log => log.completed).length
    };
  }
}

export const storage = new MemStorage();
