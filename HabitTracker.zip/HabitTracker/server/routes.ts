import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { format, parseISO } from "date-fns";
import { insertHabitSchema, insertHabitLogSchema, updateHabitLogSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = express.Router();
  
  // Habit endpoints
  apiRouter.get("/habits", async (req, res) => {
    const userId = req.query.userId ? Number(req.query.userId) : undefined;
    const habits = await storage.getHabits(userId);
    res.json(habits);
  });

  apiRouter.get("/habits/:id", async (req, res) => {
    const id = Number(req.params.id);
    const habit = await storage.getHabitById(id);
    
    if (!habit) {
      return res.status(404).json({ message: "Habit not found" });
    }
    
    res.json(habit);
  });

  apiRouter.post("/habits", async (req, res) => {
    try {
      const habitData = insertHabitSchema.parse(req.body);
      const habit = await storage.createHabit(habitData);
      res.status(201).json(habit);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to create habit" });
    }
  });

  apiRouter.put("/habits/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      const updates = insertHabitSchema.partial().parse(req.body);
      const habit = await storage.updateHabit(id, updates);
      
      if (!habit) {
        return res.status(404).json({ message: "Habit not found" });
      }
      
      res.json(habit);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to update habit" });
    }
  });

  apiRouter.delete("/habits/:id", async (req, res) => {
    const id = Number(req.params.id);
    const success = await storage.deleteHabit(id);
    
    if (!success) {
      return res.status(404).json({ message: "Habit not found" });
    }
    
    res.status(204).send();
  });

  // HabitLog endpoints
  apiRouter.get("/habit-logs/date/:date", async (req, res) => {
    try {
      const date = parseISO(req.params.date);
      const userId = req.query.userId ? Number(req.query.userId) : undefined;
      const logs = await storage.getHabitLogsForDate(date, userId);
      res.json(logs);
    } catch (error) {
      res.status(400).json({ message: "Invalid date format. Use ISO format (YYYY-MM-DD)" });
    }
  });

  apiRouter.get("/habit-logs/range", async (req, res) => {
    try {
      const startDate = req.query.startDate ? parseISO(req.query.startDate as string) : new Date();
      const endDate = req.query.endDate ? parseISO(req.query.endDate as string) : new Date();
      const userId = req.query.userId ? Number(req.query.userId) : undefined;
      
      const logs = await storage.getHabitLogsInRange(startDate, endDate, userId);
      res.json(logs);
    } catch (error) {
      res.status(400).json({ message: "Invalid date format. Use ISO format (YYYY-MM-DD)" });
    }
  });

  apiRouter.get("/habit-logs/habit/:habitId", async (req, res) => {
    const habitId = Number(req.params.habitId);
    const logs = await storage.getHabitLogsForHabit(habitId);
    res.json(logs);
  });

  apiRouter.post("/habit-logs", async (req, res) => {
    try {
      const logData = insertHabitLogSchema.parse(req.body);
      const log = await storage.createHabitLog(logData);
      res.status(201).json(log);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to create habit log" });
    }
  });

  apiRouter.put("/habit-logs/:habitId/:date", async (req, res) => {
    try {
      const habitId = Number(req.params.habitId);
      const date = parseISO(req.params.date);
      const updates = updateHabitLogSchema.parse(req.body);
      
      // Check if log exists
      let log = await storage.getHabitLog(habitId, date);
      
      if (!log) {
        // Create a new log if it doesn't exist
        log = await storage.createHabitLog({
          habitId,
          date,
          completed: updates.completed,
          userId: 1 // Use default user ID for simplicity
        });
        return res.status(201).json(log);
      }
      
      // Update existing log
      const updatedLog = await storage.updateHabitLog(habitId, date, updates);
      res.json(updatedLog);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: error.errors });
      }
      res.status(500).json({ message: "Failed to update habit log" });
    }
  });

  // Statistics endpoints
  apiRouter.get("/stats/completion-rate", async (req, res) => {
    const userId = req.query.userId ? Number(req.query.userId) : undefined;
    const days = req.query.days ? Number(req.query.days) : 7;
    const rate = await storage.getCompletionRate(userId, days);
    res.json({ rate });
  });

  apiRouter.get("/stats/streak/:habitId", async (req, res) => {
    const habitId = Number(req.params.habitId);
    const streak = await storage.getCurrentStreak(habitId);
    res.json({ streak });
  });

  apiRouter.get("/stats/today", async (req, res) => {
    const userId = req.query.userId ? Number(req.query.userId) : undefined;
    const stats = await storage.getTodayStats(userId);
    res.json(stats);
  });

  // Mount the API router
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}
