import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Habit, HabitLog } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";

export function useHabits(userId?: number) {
  const queryClient = useQueryClient();

  // Fetch all habits
  const { 
    data: habits, 
    isLoading: isLoadingHabits,
    error: habitsError 
  } = useQuery<Habit[]>({
    queryKey: ['/api/habits', userId],
  });

  // Fetch today's habit logs
  const today = format(new Date(), 'yyyy-MM-dd');
  const { 
    data: todayLogs, 
    isLoading: isLoadingTodayLogs 
  } = useQuery<HabitLog[]>({
    queryKey: ['/api/habit-logs/date', today, userId],
  });

  // Mutation to toggle habit completion
  const toggleHabitMutation = useMutation({
    mutationFn: async ({ habitId, completed }: { habitId: number; completed: boolean }) => {
      const response = await apiRequest('PUT', `/api/habit-logs/${habitId}/${today}`, { completed });
      return response.json();
    },
    onSuccess: () => {
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/habit-logs/date', today] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats/today'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats/completion-rate'] });
    }
  });

  // Mutation to create a new habit
  const createHabitMutation = useMutation({
    mutationFn: async (habitData: any) => {
      const response = await apiRequest('POST', '/api/habits', habitData);
      return response.json();
    },
    onSuccess: () => {
      // Invalidate habits query
      queryClient.invalidateQueries({ queryKey: ['/api/habits'] });
    }
  });

  return {
    habits,
    todayLogs,
    isLoading: isLoadingHabits || isLoadingTodayLogs,
    error: habitsError,
    toggleHabit: toggleHabitMutation.mutate,
    isTogglingHabit: toggleHabitMutation.isPending,
    createHabit: createHabitMutation.mutate,
    isCreatingHabit: createHabitMutation.isPending
  };
}
