import { HabitCategory } from "@shared/schema";

/**
 * Returns color related style information for a given category
 */
export function getCategoryColor(category: HabitCategory | string) {
  switch (category) {
    case 'health':
      return {
        dotColor: 'bg-primary',
        categoryColor: 'text-primary',
        categoryBgColor: 'bg-primary bg-opacity-10',
        progressColor: 'bg-primary',
        chartColor: '#4F46E5',
        categoryLabel: 'Health'
      };
    case 'productivity':
      return {
        dotColor: 'bg-green-500',
        categoryColor: 'text-green-700',
        categoryBgColor: 'bg-green-500 bg-opacity-10',
        progressColor: 'bg-green-500',
        chartColor: '#10B981',
        categoryLabel: 'Productivity'
      };
    case 'learning':
      return {
        dotColor: 'bg-amber-500',
        categoryColor: 'text-amber-700',
        categoryBgColor: 'bg-amber-500 bg-opacity-10',
        progressColor: 'bg-amber-500',
        chartColor: '#F59E0B',
        categoryLabel: 'Learning'
      };
    case 'personal':
      return {
        dotColor: 'bg-pink-500',
        categoryColor: 'text-pink-700',
        categoryBgColor: 'bg-pink-500 bg-opacity-10',
        progressColor: 'bg-pink-500',
        chartColor: '#EC4899',
        categoryLabel: 'Personal'
      };
    default:
      return {
        dotColor: 'bg-gray-500',
        categoryColor: 'text-gray-700',
        categoryBgColor: 'bg-gray-500 bg-opacity-10',
        progressColor: 'bg-gray-500',
        chartColor: '#6B7280',
        categoryLabel: 'Other'
      };
  }
}

/**
 * Returns a human-readable string for a frequency type
 */
export function getFrequencyLabel(frequencyType: string): string {
  switch (frequencyType) {
    case 'daily':
      return 'Daily';
    case 'weekdays':
      return 'Every weekday';
    case 'weekends':
      return 'Weekends only';
    case 'custom':
      return 'Custom schedule';
    default:
      return 'Unknown frequency';
  }
}

/**
 * Calculates a streak percentage for progress bars (out of 100%)
 */
export function calculateStreakPercentage(streak: number): number {
  // Cap at 100% (10+ days streak)
  return Math.min(streak * 10, 100);
}
