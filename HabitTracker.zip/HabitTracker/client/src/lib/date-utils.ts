import { format, isToday, parseISO, isValid, addDays, isAfter, isBefore, isWeekend, getDay } from 'date-fns';

/**
 * Formats a date string or Date object to display format
 */
export function formatDisplayDate(date: Date | string): string {
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return format(dateObj, 'EEEE, MMMM d');
}

/**
 * Formats a date to API format (YYYY-MM-DD)
 */
export function formatApiDate(date: Date): string {
  return format(date, 'yyyy-MM-dd');
}

/**
 * Checks if a date is today
 */
export function checkIsToday(date: Date | string): boolean {
  const dateObj = typeof date === 'string' ? parseISO(date) : date;
  return isToday(dateObj);
}

/**
 * Checks if a habit should be active on a given date based on its frequency
 */
export function isHabitActiveOnDate(
  frequencyType: string, 
  customDays: string[] | undefined, 
  date: Date
): boolean {
  if (!isValid(date)) return false;
  
  switch (frequencyType) {
    case 'daily':
      return true;
    case 'weekdays':
      return !isWeekend(date);
    case 'weekends':
      return isWeekend(date);
    case 'custom':
      if (!customDays || customDays.length === 0) return false;
      const dayName = format(date, 'EEEE').toLowerCase();
      return customDays.includes(dayName);
    default:
      return false;
  }
}

/**
 * Gets the next occurrence of a habit based on its frequency
 */
export function getNextOccurrence(
  frequencyType: string, 
  customDays: string[] | undefined, 
  fromDate = new Date()
): Date | null {
  let currentDate = fromDate;
  
  // Look ahead up to 30 days maximum
  for (let i = 0; i < 30; i++) {
    currentDate = addDays(currentDate, 1);
    if (isHabitActiveOnDate(frequencyType, customDays, currentDate)) {
      return currentDate;
    }
  }
  
  return null;
}

/**
 * Returns day of week as a number (0-6, where 0 is Sunday)
 */
export function getDayOfWeek(date: Date): number {
  return getDay(date);
}
