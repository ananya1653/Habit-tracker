import { useState } from "react";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { Check, X } from "lucide-react";
import { getCategoryColor } from "@/lib/habits";

export default function Calendar() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  
  // Format selected date for API request
  const formattedDate = selectedDate ? format(selectedDate, 'yyyy-MM-dd') : '';
  
  // Fetch habits
  const { data: habits, isLoading: isLoadingHabits } = useQuery({
    queryKey: ['/api/habits'],
  });
  
  // Fetch logs for the selected date
  const { data: habitLogs, isLoading: isLoadingLogs } = useQuery({
    queryKey: ['/api/habit-logs/date', formattedDate],
    enabled: !!formattedDate,
  });
  
  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-2xl font-semibold mb-6">Calendar</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-1">
          <CardContent className="p-4">
            <CalendarComponent
              mode="single"
              selected={selectedDate}
              onSelect={setSelectedDate}
              className="w-full"
            />
          </CardContent>
        </Card>
        
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>
              {selectedDate ? format(selectedDate, 'MMMM d, yyyy') : 'Select a date'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoadingHabits || isLoadingLogs ? (
              <p className="text-gray-500">Loading habits...</p>
            ) : habits && habits.length > 0 ? (
              <div className="space-y-4">
                {habits.map((habit: any) => {
                  // Find log for this habit on selected date
                  const log = habitLogs?.find((l: any) => l.habitId === habit.id);
                  const { categoryLabel, dotColor } = getCategoryColor(habit.category);
                  
                  return (
                    <div key={habit.id} className="flex items-center p-3 border rounded-lg">
                      <div className="mr-3">
                        {log ? (
                          log.completed ? (
                            <div className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                              <Check className="h-5 w-5 text-green-600" />
                            </div>
                          ) : (
                            <div className="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center">
                              <X className="h-5 w-5 text-red-600" />
                            </div>
                          )
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                            <span className="text-gray-400">?</span>
                          </div>
                        )}
                      </div>
                      <div>
                        <h3 className="font-medium">{habit.name}</h3>
                        <div className="flex items-center mt-1">
                          <span className={`inline-block w-2 h-2 ${dotColor} rounded-full mr-2`}></span>
                          <span className="text-xs text-gray-500">{categoryLabel}</span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8">
                No habits found. Create your first habit on the Dashboard.
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
