import { useEffect, useState } from "react";
import { format, addDays, subDays } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, CalendarDays, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import StatsSummary from "@/components/dashboard/StatsSummary";
import HabitCard from "@/components/dashboard/HabitCard";
import WeeklyOverview from "@/components/dashboard/WeeklyOverview";
import CategoryFilter from "@/components/dashboard/CategoryFilter";
import NewHabitDialog from "@/components/habit/NewHabitDialog";
import { Card } from "@/components/ui/card";

export default function Dashboard() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [newHabitDialogOpen, setNewHabitDialogOpen] = useState(false);
  
  // Format the selected date for display and API requests
  const formattedDate = format(selectedDate, 'yyyy-MM-dd');
  const displayDate = format(selectedDate, 'EEEE, MMMM d');
  const isToday = format(selectedDate, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
  
  // Fetch habits data
  const { data: habits, isLoading: isLoadingHabits } = useQuery({
    queryKey: ['/api/habits'],
  });
  
  // Fetch habit logs for the selected date
  const { data: habitLogs, isLoading: isLoadingLogs } = useQuery({
    queryKey: ['/api/habit-logs/date', formattedDate],
  });
  
  // Navigation functions
  const goToPreviousDay = () => setSelectedDate(subDays(selectedDate, 1));
  const goToNextDay = () => setSelectedDate(addDays(selectedDate, 1));
  const goToToday = () => setSelectedDate(new Date());
  
  // Filter habits by category if one is selected
  const filteredHabits = habits
    ? selectedCategory 
      ? habits.filter((habit: any) => habit.category === selectedCategory)
      : habits
    : [];

  // Generate streaks and streak visualization data
  // This would normally come from the API, but we're simulating it for this example
  const getStreakData = (habitId: number) => {
    // Simulated streak data (would normally come from API)
    const streakMap: Record<number, { streak: number, dots: Array<'completed' | 'missed' | 'skipped' | 'upcoming'> }> = {
      1: { 
        streak: 8, 
        dots: ['completed', 'completed', 'completed', 'completed', 'completed', 'skipped', 'completed'] 
      },
      2: { 
        streak: 12, 
        dots: ['completed', 'completed', 'completed', 'completed', 'completed', 'completed', 'completed'] 
      },
      3: { 
        streak: 3, 
        dots: ['completed', 'completed', 'completed', 'skipped', 'missed', 'skipped', 'skipped'] 
      },
      4: { 
        streak: 5, 
        dots: ['completed', 'completed', 'skipped', 'completed', 'completed', 'completed', 'skipped'] 
      }
    };
    
    return streakMap[habitId] || { streak: 0, dots: Array(7).fill('skipped') };
  };
  
  return (
    <div className="max-w-6xl mx-auto">
      {/* Page header with date selector */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold mb-1">Dashboard</h1>
          <p className="text-gray-500">{displayDate}</p>
        </div>
        
        <div className="mt-4 md:mt-0 flex items-center">
          <Button variant="ghost" size="icon" onClick={goToPreviousDay}>
            <ChevronLeft className="h-5 w-5 text-gray-600" />
          </Button>
          <Button 
            variant="ghost" 
            className="text-sm font-medium"
            onClick={goToToday}
          >
            {isToday ? 'Today' : 'Go to Today'}
          </Button>
          <Button variant="ghost" size="icon" onClick={goToNextDay}>
            <ChevronRight className="h-5 w-5 text-gray-600" />
          </Button>
          <Button variant="outline" className="ml-4" onClick={goToToday}>
            <CalendarDays className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">View Calendar</span>
          </Button>
        </div>
      </div>
      
      {/* Stats summary */}
      <StatsSummary userId={1} />
      
      {/* Category filters */}
      <CategoryFilter 
        activeCategory={selectedCategory} 
        onChange={setSelectedCategory} 
      />
      
      {/* Today's Habits */}
      <div className="mb-8">
        <h2 className="text-lg font-semibold mb-4">
          {isToday ? "Today's Habits" : `Habits for ${format(selectedDate, 'MMMM d')}`}
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {isLoadingHabits || isLoadingLogs ? (
            Array(4).fill(0).map((_, index) => (
              <Card key={index} className="h-40 animate-pulse bg-gray-100" />
            ))
          ) : filteredHabits.length > 0 ? (
            filteredHabits.map((habit: any) => {
              // Find the log for this habit on the selected date
              const log = habitLogs?.find((l: any) => l.habitId === habit.id);
              const isCompleted = log?.completed || false;
              const { streak, dots } = getStreakData(habit.id);
              
              return (
                <HabitCard 
                  key={habit.id}
                  habit={habit}
                  isCompleted={isCompleted}
                  streak={streak}
                  streakDots={dots}
                />
              );
            })
          ) : (
            <div className="col-span-2 text-center py-8">
              <p className="text-gray-500">No habits found. Create your first habit to get started!</p>
            </div>
          )}
          
          {/* Add New Habit Card */}
          <Card 
            className="border-dashed flex items-center justify-center cursor-pointer hover:bg-gray-50"
            onClick={() => setNewHabitDialogOpen(true)}
          >
            <div className="text-center p-5">
              <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-2">
                <Plus className="h-6 w-6 text-primary" />
              </div>
              <p className="font-medium text-primary">Add New Habit</p>
            </div>
          </Card>
        </div>
      </div>
      
      {/* Weekly Overview */}
      <div className="mb-8">
        <h2 className="text-lg font-semibold mb-4">Weekly Overview</h2>
        <WeeklyOverview userId={1} />
      </div>
      
      {/* New Habit Dialog */}
      <NewHabitDialog 
        open={newHabitDialogOpen} 
        onOpenChange={setNewHabitDialogOpen} 
      />
    </div>
  );
}
