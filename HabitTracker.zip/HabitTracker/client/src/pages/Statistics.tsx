import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { format, subDays } from "date-fns";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Button } from "@/components/ui/button";
import { HABIT_CATEGORIES, HabitCategory } from "@shared/schema";
import { getCategoryColor } from "@/lib/habits";

const timeRanges = [
  { label: '7 days', days: 7 },
  { label: '30 days', days: 30 },
  { label: '90 days', days: 90 }
];

export default function Statistics() {
  const [selectedRange, setSelectedRange] = useState(timeRanges[0]);
  
  // Calculate date range
  const endDate = new Date();
  const startDate = subDays(endDate, selectedRange.days);
  
  // Format dates for API
  const formattedStartDate = format(startDate, 'yyyy-MM-dd');
  const formattedEndDate = format(endDate, 'yyyy-MM-dd');
  
  // Fetch habits
  const { data: habits, isLoading: isLoadingHabits } = useQuery({
    queryKey: ['/api/habits'],
  });
  
  // Fetch completion rate
  const { data: completionRateData } = useQuery({
    queryKey: ['/api/stats/completion-rate', { days: selectedRange.days }],
  });
  
  // Fetch logs for date range
  const { data: logsByDate, isLoading: isLoadingLogs } = useQuery({
    queryKey: ['/api/habit-logs/range', { startDate: formattedStartDate, endDate: formattedEndDate }],
  });
  
  // Process data for charts
  const completionRate = completionRateData?.rate || 0;
  
  // Category distribution
  const categoryDistribution = habits ? HABIT_CATEGORIES.map(category => {
    const count = habits.filter((h: any) => h.category === category).length;
    return {
      name: category.charAt(0).toUpperCase() + category.slice(1),
      value: count,
      color: getCategoryColor(category as HabitCategory).chartColor
    };
  }).filter(item => item.value > 0) : [];
  
  // Daily completion data
  const dailyCompletionData = [];
  if (logsByDate) {
    // Group logs by date
    const groupedByDate: Record<string, any[]> = {};
    
    for (const log of logsByDate) {
      const date = format(new Date(log.date), 'MMM d');
      if (!groupedByDate[date]) {
        groupedByDate[date] = [];
      }
      groupedByDate[date].push(log);
    }
    
    // Calculate completion percentage for each date
    for (const [date, logs] of Object.entries(groupedByDate)) {
      const totalLogs = logs.length;
      const completedLogs = logs.filter(log => log.completed).length;
      const percentage = totalLogs > 0 ? Math.round((completedLogs / totalLogs) * 100) : 0;
      
      dailyCompletionData.push({
        date,
        completion: percentage
      });
    }
  }
  
  return (
    <div className="max-w-6xl mx-auto">
      <h1 className="text-2xl font-semibold mb-6">Statistics</h1>
      
      <div className="flex mb-6 space-x-2">
        {timeRanges.map((range) => (
          <Button
            key={range.days}
            variant={selectedRange.days === range.days ? "default" : "outline"}
            onClick={() => setSelectedRange(range)}
          >
            {range.label}
          </Button>
        ))}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Completion Rate</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center p-6">
            <div className="relative w-40 h-40">
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-3xl font-bold">{completionRate}%</span>
              </div>
              <PieChart width={160} height={160}>
                <Pie
                  data={[
                    { name: 'Completed', value: completionRate },
                    { name: 'Missed', value: 100 - completionRate }
                  ]}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  <Cell fill="#4F46E5" />
                  <Cell fill="#E5E7EB" />
                </Pie>
              </PieChart>
            </div>
            <p className="mt-4 text-gray-500">Last {selectedRange.days} days</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Habits by Category</CardTitle>
          </CardHeader>
          <CardContent className="h-64">
            {isLoadingHabits ? (
              <div className="h-full flex items-center justify-center">
                <p className="text-gray-500">Loading data...</p>
              </div>
            ) : categoryDistribution.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryDistribution}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {categoryDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => [`${value} habits`, 'Count']} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center">
                <p className="text-gray-500">No habits data available</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Daily Completion Rate</CardTitle>
        </CardHeader>
        <CardContent className="h-80">
          {isLoadingLogs ? (
            <div className="h-full flex items-center justify-center">
              <p className="text-gray-500">Loading data...</p>
            </div>
          ) : dailyCompletionData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dailyCompletionData} margin={{ top: 20, right: 30, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="date" />
                <YAxis domain={[0, 100]} unit="%" />
                <Tooltip formatter={(value) => [`${value}%`, 'Completion Rate']} />
                <Bar dataKey="completion" fill="#4F46E5" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center">
              <p className="text-gray-500">No completion data available for the selected period</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
