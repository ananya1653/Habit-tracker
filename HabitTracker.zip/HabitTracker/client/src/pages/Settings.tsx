import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const [dailyReminders, setDailyReminders] = useState(true);
  const [weeklyReports, setWeeklyReports] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const { toast } = useToast();
  
  const handleSaveSettings = () => {
    // In a real app, this would save to an API/backend
    toast({
      title: "Settings Saved",
      description: "Your preferences have been updated successfully.",
    });
  };
  
  const handleResetHabits = () => {
    // This would normally show a confirmation dialog and then reset data
    toast({
      title: "Are you sure?",
      description: "This action would reset all your habit data.",
      variant: "destructive",
    });
  };
  
  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-2xl font-semibold mb-6">Settings</h1>
      
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Notification Preferences</CardTitle>
            <CardDescription>Configure when and how you receive notifications</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="daily-reminders" className="font-medium">Daily Reminders</Label>
                <p className="text-sm text-gray-500">Get reminders for incomplete habits</p>
              </div>
              <Switch 
                id="daily-reminders" 
                checked={dailyReminders} 
                onCheckedChange={setDailyReminders} 
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="weekly-reports" className="font-medium">Weekly Reports</Label>
                <p className="text-sm text-gray-500">Receive a summary of your progress</p>
              </div>
              <Switch 
                id="weekly-reports" 
                checked={weeklyReports} 
                onCheckedChange={setWeeklyReports} 
              />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Display Settings</CardTitle>
            <CardDescription>Customize your app experience</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="dark-mode" className="font-medium">Dark Mode</Label>
                <p className="text-sm text-gray-500">Use dark theme throughout the app</p>
              </div>
              <Switch 
                id="dark-mode" 
                checked={darkMode} 
                onCheckedChange={setDarkMode} 
              />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Data Management</CardTitle>
            <CardDescription>Manage your habit data</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <h3 className="font-medium mb-2">Export Data</h3>
              <p className="text-sm text-gray-500 mb-4">Download your habit data as a CSV file</p>
              <Button variant="outline">Export Data</Button>
            </div>
            
            <Separator />
            
            <div>
              <h3 className="font-medium text-red-600 mb-2">Danger Zone</h3>
              <p className="text-sm text-gray-500 mb-4">Permanently delete all your habits and history</p>
              <Button variant="destructive" onClick={handleResetHabits}>
                Reset All Habits
              </Button>
            </div>
          </CardContent>
        </Card>
        
        <div className="flex justify-end">
          <Button onClick={handleSaveSettings}>Save Settings</Button>
        </div>
      </div>
    </div>
  );
}
