import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm, Controller } from "react-hook-form";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertHabitSchema, HABIT_CATEGORIES, FREQUENCY_TYPES } from "@shared/schema";
import { getCategoryColor } from "@/lib/habits";

interface NewHabitDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const DAYS_OF_WEEK = [
  "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"
];

export default function NewHabitDialog({ open, onOpenChange }: NewHabitDialogProps) {
  const [showCustomDays, setShowCustomDays] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { register, handleSubmit, control, reset, formState: { errors } } = useForm({
    resolver: zodResolver(insertHabitSchema),
    defaultValues: {
      name: "",
      description: "",
      category: "health",
      frequencyType: "daily",
      customDays: [],
      userId: 1 // Default user
    }
  });
  
  const createHabitMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('POST', '/api/habits', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Habit created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/habits'] });
      reset();
      onOpenChange(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create habit. Please try again.",
        variant: "destructive",
      });
      console.error("Error creating habit:", error);
    }
  });
  
  const onSubmit = (data: any) => {
    // Only include customDays if frequencyType is 'custom'
    if (data.frequencyType !== 'custom') {
      delete data.customDays;
    }
    
    createHabitMutation.mutate(data);
  };
  
  const handleFrequencyChange = (value: string) => {
    setShowCustomDays(value === 'custom');
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">Create New Habit</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="name">Habit Name</Label>
              <Input 
                id="name" 
                placeholder="e.g., Morning Run" 
                {...register("name")}
              />
              {errors.name && (
                <p className="text-sm text-red-500">{errors.name.message as string}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description">Description (optional)</Label>
              <Textarea 
                id="description" 
                placeholder="Describe your habit..." 
                {...register("description")}
              />
            </div>
            
            <div className="space-y-2">
              <Label>Category</Label>
              <div className="grid grid-cols-2 gap-3">
                <Controller
                  name="category"
                  control={control}
                  render={({ field }) => (
                    <RadioGroup
                      onValueChange={(value) => {
                        field.onChange(value);
                      }}
                      value={field.value}
                      className="grid grid-cols-2 gap-3"
                    >
                      {HABIT_CATEGORIES.map((category) => {
                        const { dotColor, categoryLabel } = getCategoryColor(category);
                        return (
                          <div 
                            key={category}
                            className={`flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50 ${
                              field.value === category ? 'border-primary bg-blue-50' : 'border-gray-300'
                            }`}
                          >
                            <RadioGroupItem value={category} id={`category-${category}`} className="sr-only" />
                            <span className={`w-4 h-4 rounded-full ${dotColor} mr-3`}></span>
                            <Label htmlFor={`category-${category}`} className="cursor-pointer">
                              {categoryLabel}
                            </Label>
                          </div>
                        );
                      })}
                    </RadioGroup>
                  )}
                />
              </div>
              {errors.category && (
                <p className="text-sm text-red-500">{errors.category.message as string}</p>
              )}
            </div>
            
            <div className="space-y-2">
              <Label>Frequency</Label>
              <Controller
                name="frequencyType"
                control={control}
                render={({ field }) => (
                  <RadioGroup
                    onValueChange={(value) => {
                      field.onChange(value);
                      handleFrequencyChange(value);
                    }}
                    value={field.value}
                    className="space-y-2"
                  >
                    {FREQUENCY_TYPES.map((frequencyType) => (
                      <div key={frequencyType} className="flex items-center">
                        <RadioGroupItem value={frequencyType} id={`frequency-${frequencyType}`} />
                        <Label htmlFor={`frequency-${frequencyType}`} className="ml-3 cursor-pointer">
                          {frequencyType === 'daily' ? 'Daily' :
                           frequencyType === 'weekdays' ? 'Weekdays only' :
                           frequencyType === 'weekends' ? 'Weekends only' : 'Custom'}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                )}
              />
              {errors.frequencyType && (
                <p className="text-sm text-red-500">{errors.frequencyType.message as string}</p>
              )}
            </div>
            
            {showCustomDays && (
              <div className="space-y-2">
                <Label>Select Days</Label>
                <div className="flex flex-wrap gap-2">
                  <Controller
                    name="customDays"
                    control={control}
                    render={({ field }) => (
                      <>
                        {DAYS_OF_WEEK.map((day) => {
                          const isSelected = field.value?.includes(day);
                          return (
                            <Label
                              key={day}
                              className={`px-3 py-2 border rounded-lg cursor-pointer hover:bg-gray-50 ${
                                isSelected ? 'border-primary bg-blue-50 text-primary' : 'border-gray-300'
                              }`}
                            >
                              <Checkbox
                                checked={isSelected}
                                onCheckedChange={(checked) => {
                                  const currentValue = field.value || [];
                                  const newValue = checked
                                    ? [...currentValue, day]
                                    : currentValue.filter((d: string) => d !== day);
                                  field.onChange(newValue);
                                }}
                                className="sr-only"
                              />
                              {day.slice(0, 3)}
                            </Label>
                          );
                        })}
                      </>
                    )}
                  />
                </div>
                {errors.customDays && (
                  <p className="text-sm text-red-500">{errors.customDays.message as string}</p>
                )}
              </div>
            )}
          </div>
          
          <DialogFooter className="mt-6">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={createHabitMutation.isPending}>
              {createHabitMutation.isPending ? "Creating..." : "Create Habit"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
