import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  CalendarDays, 
  BarChart, 
  Settings as SettingsIcon, 
  X 
} from "lucide-react";

interface SidebarProps {
  open: boolean;
  onClose: () => void;
}

export default function Sidebar({ open, onClose }: SidebarProps) {
  const [location] = useLocation();

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <>
      {/* Mobile sidebar overlay */}
      {open && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden"
          onClick={onClose}
        />
      )}
      
      {/* Sidebar */}
      <aside 
        className={`
          fixed top-0 left-0 h-full w-64 bg-white border-r border-gray-200 p-4 
          overflow-y-auto transition-transform duration-300 ease-in-out z-50
          md:static md:translate-x-0 md:block
          ${open ? 'translate-x-0' : '-translate-x-full'}
        `}
      >
        <div className="flex justify-between items-center mb-6 md:hidden">
          <h1 className="text-2xl font-semibold text-primary">HabitTrack</h1>
          <button 
            className="p-2 rounded-lg hover:bg-gray-100"
            onClick={onClose}
          >
            <X size={20} />
          </button>
        </div>
        
        <div className="hidden md:block mb-6">
          <h1 className="text-2xl font-semibold text-primary mb-1">HabitTrack</h1>
          <p className="text-sm text-gray-500">Build better habits, one day at a time</p>
        </div>
        
        <nav className="mb-8">
          <ul>
            <li className="mb-1">
              <Link href="/">
                <a className={`flex items-center px-4 py-2 rounded-lg ${
                  isActive("/") 
                    ? "text-primary bg-blue-50" 
                    : "text-gray-600 hover:bg-gray-100"
                }`}>
                  <LayoutDashboard className="mr-3 h-5 w-5" />
                  Dashboard
                </a>
              </Link>
            </li>
            <li className="mb-1">
              <Link href="/calendar">
                <a className={`flex items-center px-4 py-2 rounded-lg ${
                  isActive("/calendar") 
                    ? "text-primary bg-blue-50" 
                    : "text-gray-600 hover:bg-gray-100"
                }`}>
                  <CalendarDays className="mr-3 h-5 w-5" />
                  Calendar
                </a>
              </Link>
            </li>
            <li className="mb-1">
              <Link href="/statistics">
                <a className={`flex items-center px-4 py-2 rounded-lg ${
                  isActive("/statistics") 
                    ? "text-primary bg-blue-50" 
                    : "text-gray-600 hover:bg-gray-100"
                }`}>
                  <BarChart className="mr-3 h-5 w-5" />
                  Statistics
                </a>
              </Link>
            </li>
            <li className="mb-1">
              <Link href="/settings">
                <a className={`flex items-center px-4 py-2 rounded-lg ${
                  isActive("/settings") 
                    ? "text-primary bg-blue-50" 
                    : "text-gray-600 hover:bg-gray-100"
                }`}>
                  <SettingsIcon className="mr-3 h-5 w-5" />
                  Settings
                </a>
              </Link>
            </li>
          </ul>
        </nav>
        
        <div className="border-t border-gray-200 pt-4">
          <h2 className="text-xs uppercase text-gray-500 font-semibold mb-2">Categories</h2>
          <ul>
            <li className="mb-1">
              <a href="#" className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">
                <span className="w-2 h-2 bg-primary rounded-full mr-3"></span>
                Health
              </a>
            </li>
            <li className="mb-1">
              <a href="#" className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">
                <span className="w-2 h-2 bg-green-500 rounded-full mr-3"></span>
                Productivity
              </a>
            </li>
            <li className="mb-1">
              <a href="#" className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">
                <span className="w-2 h-2 bg-amber-500 rounded-full mr-3"></span>
                Learning
              </a>
            </li>
            <li className="mb-1">
              <a href="#" className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">
                <span className="w-2 h-2 bg-pink-500 rounded-full mr-3"></span>
                Personal
              </a>
            </li>
          </ul>
        </div>
      </aside>
    </>
  );
}
