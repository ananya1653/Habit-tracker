import { Link, useLocation } from "wouter";
import { LayoutDashboard, CalendarDays, BarChart, Settings, Plus } from "lucide-react";
import { useState } from "react";
import NewHabitDialog from "../habit/NewHabitDialog";

export default function BottomNav() {
  const [location] = useLocation();
  const [showNewHabitDialog, setShowNewHabitDialog] = useState(false);

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <>
      <div className="md:hidden bg-white border-t border-gray-200 px-6 py-3">
        <div className="flex justify-between items-center">
          <Link href="/">
            <a className={`flex flex-col items-center ${isActive("/") ? "text-primary" : "text-gray-400"}`}>
              <LayoutDashboard size={20} />
              <span className="text-xs mt-1">Dashboard</span>
            </a>
          </Link>
          
          <Link href="/calendar">
            <a className={`flex flex-col items-center ${isActive("/calendar") ? "text-primary" : "text-gray-400"}`}>
              <CalendarDays size={20} />
              <span className="text-xs mt-1">Calendar</span>
            </a>
          </Link>
          
          <div className="relative -mt-8">
            <button 
              className="w-14 h-14 rounded-full bg-primary text-white flex items-center justify-center shadow-lg"
              onClick={() => setShowNewHabitDialog(true)}
            >
              <Plus size={24} />
            </button>
          </div>
          
          <Link href="/statistics">
            <a className={`flex flex-col items-center ${isActive("/statistics") ? "text-primary" : "text-gray-400"}`}>
              <BarChart size={20} />
              <span className="text-xs mt-1">Stats</span>
            </a>
          </Link>
          
          <Link href="/settings">
            <a className={`flex flex-col items-center ${isActive("/settings") ? "text-primary" : "text-gray-400"}`}>
              <Settings size={20} />
              <span className="text-xs mt-1">Settings</span>
            </a>
          </Link>
        </div>
      </div>

      <NewHabitDialog 
        open={showNewHabitDialog} 
        onOpenChange={setShowNewHabitDialog}
      />
    </>
  );
}
