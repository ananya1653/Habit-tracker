import { Menu } from "lucide-react";

interface HeaderProps {
  onMenuClick: () => void;
}

export default function Header({ onMenuClick }: HeaderProps) {
  return (
    <header className="md:hidden bg-white border-b border-gray-200 p-4">
      <div className="flex justify-between items-center">
        <h1 className="text-xl font-semibold text-primary">HabitTrack</h1>
        <button 
          className="p-2 rounded-lg hover:bg-gray-100"
          onClick={onMenuClick}
        >
          <Menu size={20} />
        </button>
      </div>
    </header>
  );
}
