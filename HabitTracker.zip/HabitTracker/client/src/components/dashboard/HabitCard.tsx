import { Card, CardContent } from "@/components/ui/card";
import { Habit } from "@shared/schema";
import { useState } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { getCategoryColor } from "@/lib/habits";

interface HabitCardProps {
  habit: Habit;
  isCompleted: boolean;
  streak: number;
  streakDots: Array<'completed' | 'missed' | 'skipped' | 'upcoming'>;
}

export default function HabitCard({ 
  habit, 
  isCompleted, 
  streak, 
  streakDots 
}: HabitCardProps) {
  const [checked, setChecked] = useState(isCompleted);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const { category, name, description, frequencyType } = habit;
  
  const { categoryColor, categoryBgColor, categoryLabel } = getCategoryColor(category);
  
  const frequencyLabel = 
    frequencyType === 'daily' ? 'Daily' :
    frequencyType === 'weekdays' ? 'Every weekday' :
    frequencyType === 'weekends' ? 'Weekends only' : 'Custom';
  
  const today = format(new Date(), 'yyyy-MM-dd');
  
  const toggleHabitMutation = useMutation({
    mutationFn: async () => {
      const result = await apiRequest('PUT', `/api/habit-logs/${habit.id}/${today}`, {
        completed: !checked
      });
      return result.json();
    },
    onSuccess: () => {
      setChecked(!checked);
      queryClient.invalidateQueries({ queryKey: ['/api/stats/today'] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats/completion-rate'] });
      queryClient.invalidateQueries({ queryKey: ['/api/habit-logs/date', today] });
      toast({
        title: checked ? "Habit marked as incomplete" : "Habit completed!",
        description: checked ? "Keep trying, you can do it!" : "Great job, keep up the good work!",
        variant: checked ? "destructive" : "default",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update habit status. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  const handleToggle = () => {
    toggleHabitMutation.mutate();
  };
  
  // Calculate streak percentage for progress bar
  const streakPercentage = Math.min(streak * 10, 100);
  
  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex justify-between">
          <div className="flex items-start">
            <div>
              {/* Toggle checkbox for habit completion */}
              <label className="flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  className="hidden peer" 
                  checked={checked} 
                  onChange={handleToggle}
                  disabled={toggleHabitMutation.isPending}
                />
                <div className={`w-6 h-6 border border-gray-300 rounded-full flex items-center justify-center 
                  ${checked ? 'bg-green-500 border-green-500' : ''}`}
                >
                  <svg 
                    className={`w-3 h-3 text-white ${checked ? 'opacity-100' : 'opacity-0'}`} 
                    fill="none" 
                    stroke="currentColor" 
                    viewBox="0 0 24 24" 
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
                  </svg>
                </div>
              </label>
            </div>
            <div className="ml-3">
              <h3 className="font-medium text-lg">{name}</h3>
              <p className="text-sm text-gray-500 mt-1">{description}</p>
              <div className="flex items-center mt-2">
                <span className={`text-xs px-2 py-1 ${categoryBgColor} ${categoryColor} rounded-full`}>
                  {categoryLabel}
                </span>
                <span className="text-xs ml-2 text-gray-500">{frequencyLabel}</span>
              </div>
            </div>
          </div>
        </div>
        <div className="mt-4">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span>Current streak</span>
              <span className="font-medium">{streak} days</span>
            </div>
            <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
              <div 
                className={`h-full ${getCategoryColor(category).progressColor} rounded-full`} 
                style={{ width: `${streakPercentage}%` }}
              ></div>
            </div>
          </div>
          <div className="mt-3 flex space-x-1">
            {/* Streak dots visualization */}
            {streakDots.map((status, index) => (
              <div
                key={index}
                className={`streak-dot w-2 h-2 rounded-full ${
                  status === 'completed' ? getCategoryColor(category).dotColor :
                  status === 'missed' ? 'bg-red-500' :
                  'bg-gray-200'
                }`}
              ></div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
