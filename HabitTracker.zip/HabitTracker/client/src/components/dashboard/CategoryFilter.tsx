import { HABIT_CATEGORIES, type HabitCategory } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { getCategoryColor } from "@/lib/habits";

interface CategoryFilterProps {
  activeCategory: string | null;
  onChange: (category: string | null) => void;
}

export default function CategoryFilter({ activeCategory, onChange }: CategoryFilterProps) {
  return (
    <div className="flex flex-nowrap mb-6 overflow-x-auto py-1 -mx-1 md:px-0">
      <Button
        variant={activeCategory === null ? "default" : "outline"}
        className="whitespace-nowrap mx-1"
        onClick={() => onChange(null)}
      >
        All Habits
      </Button>
      
      {HABIT_CATEGORIES.map((category) => {
        const { dotColor } = getCategoryColor(category);
        const isActive = activeCategory === category;
        
        return (
          <Button
            key={category}
            variant={isActive ? "default" : "outline"}
            className={`whitespace-nowrap mx-1 ${isActive ? "" : "border border-gray-200"}`}
            onClick={() => onChange(category)}
          >
            <span className={`w-2 h-2 inline-block ${dotColor} rounded-full mr-2`}></span>
            {category.charAt(0).toUpperCase() + category.slice(1)}
          </Button>
        );
      })}
    </div>
  );
}
