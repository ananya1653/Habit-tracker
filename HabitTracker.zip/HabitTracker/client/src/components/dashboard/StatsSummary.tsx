import { useQuery } from "@tanstack/react-query";
import { BarChart3, Activity, Flame, Brain } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface StatsSummaryProps {
  userId?: number;
}

export default function StatsSummary({ userId }: StatsSummaryProps) {
  // Query to get today's habits stats
  const { data: todayStats, isLoading: isLoadingToday } = useQuery({
    queryKey: ['/api/stats/today', userId],
    staleTime: 1000 * 60, // Refresh every minute
  });

  // Query to get completion rate
  const { data: completionRateData, isLoading: isLoadingRate } = useQuery({
    queryKey: ['/api/stats/completion-rate', userId],
    staleTime: 1000 * 60 * 60, // Refresh every hour
  });

  // Query to get all habits
  const { data: habits, isLoading: isLoadingHabits } = useQuery({
    queryKey: ['/api/habits', userId],
  });

  // Calculate the number of categories
  const categoryCount = habits ? new Set(habits.map((h: any) => h.category)).size : 0;

  // Placeholder for streak data - in a real app this would also be fetched from the API
  const currentStreak = 12;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <Card>
        <CardContent className="p-5">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 mb-1">Today's Habits</p>
              <h3 className="text-2xl font-semibold">
                {isLoadingToday ? '...' : todayStats?.total || 0}
              </h3>
            </div>
            <div className="bg-blue-50 p-2 rounded-lg">
              <Activity className="h-5 w-5 text-primary" />
            </div>
          </div>
          <div className="mt-4">
            <p className="text-sm text-gray-500 flex items-center">
              <span className="text-green-500 mr-1">✓</span>
              <span>{isLoadingToday ? '...' : todayStats?.completed || 0}</span> completed
            </p>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-5">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 mb-1">Current Streak</p>
              <h3 className="text-2xl font-semibold">{currentStreak}</h3>
            </div>
            <div className="bg-orange-50 p-2 rounded-lg">
              <Flame className="h-5 w-5 text-amber-500" />
            </div>
          </div>
          <div className="mt-4">
            <p className="text-sm text-gray-500">days in a row</p>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-5">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 mb-1">Completion Rate</p>
              <h3 className="text-2xl font-semibold">
                {isLoadingRate ? '...' : `${completionRateData?.rate || 0}%`}
              </h3>
            </div>
            <div className="bg-green-50 p-2 rounded-lg">
              <BarChart3 className="h-5 w-5 text-green-500" />
            </div>
          </div>
          <div className="mt-4">
            <p className="text-sm text-gray-500">last 7 days</p>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-5">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm text-gray-500 mb-1">Total Habits</p>
              <h3 className="text-2xl font-semibold">
                {isLoadingHabits ? '...' : habits?.length || 0}
              </h3>
            </div>
            <div className="bg-purple-50 p-2 rounded-lg">
              <Brain className="h-5 w-5 text-indigo-500" />
            </div>
          </div>
          <div className="mt-4">
            <p className="text-sm text-gray-500">
              across {categoryCount} categories
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
