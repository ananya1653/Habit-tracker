import { Card, CardContent } from "@/components/ui/card";
import { format, addDays, startOfWeek, isSameDay } from "date-fns";
import { useQuery } from "@tanstack/react-query";
import { Check, X } from "lucide-react";
import { getCategoryColor } from "@/lib/habits";

interface WeeklyOverviewProps {
  userId?: number;
}

export default function WeeklyOverview({ userId }: WeeklyOverviewProps) {
  // Get the start of the current week (Monday)
  const startDate = startOfWeek(new Date(), { weekStartsOn: 1 });
  
  // Create an array with 7 days starting from Monday
  const weekDays = Array.from({ length: 7 }).map((_, index) => {
    const date = addDays(startDate, index);
    return {
      name: format(date, 'EEE'),
      day: format(date, 'd'),
      date,
      isPast: date < new Date(),
      isToday: isSameDay(date, new Date()),
    };
  });

  // Fetch all habits
  const { data: habits, isLoading: isLoadingHabits } = useQuery({
    queryKey: ['/api/habits', userId],
  });

  // Format dates for API request
  const formattedStartDate = format(startDate, 'yyyy-MM-dd');
  const formattedEndDate = format(addDays(startDate, 6), 'yyyy-MM-dd');

  // Fetch logs for the week
  const { data: weekLogs, isLoading: isLoadingLogs } = useQuery({
    queryKey: ['/api/habit-logs/range', { startDate: formattedStartDate, endDate: formattedEndDate, userId }],
  });

  // Group logs by habit ID for easier lookup
  const groupedLogs = weekLogs ? weekLogs.reduce((acc: Record<string, any[]>, log: any) => {
    if (!acc[log.habitId]) {
      acc[log.habitId] = [];
    }
    acc[log.habitId].push(log);
    return acc;
  }, {}) : {};

  if (isLoadingHabits || isLoadingLogs) {
    return (
      <Card>
        <CardContent className="p-6 flex items-center justify-center h-40">
          <p className="text-gray-500">Loading weekly overview...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-6">
        {/* Week days header */}
        <div className="grid grid-cols-7 gap-2 mb-6">
          {weekDays.map((day, index) => (
            <div key={index} className="text-center">
              <p className="text-xs text-gray-500 mb-1">{day.name}</p>
              <div className={`h-2 w-2 mx-auto mb-1 rounded-full ${
                day.isToday ? 'bg-green-500' : 
                day.isPast ? 'bg-gray-400' : 'bg-gray-200'
              }`}></div>
              <p className={`text-sm ${
                day.isToday ? 'font-medium' : ''
              }`}>{day.day}</p>
            </div>
          ))}
        </div>

        {/* Habits progress for the week */}
        <div className="space-y-4">
          {habits && habits.map((habit: any) => {
            const habitLogs = groupedLogs[habit.id] || [];
            
            return (
              <div key={habit.id} className="flex items-center">
                <div className={`w-3 h-3 rounded-full ${getCategoryColor(habit.category).dotColor}`}></div>
                <div className="ml-3 flex-1">
                  <p className="text-sm font-medium">{habit.name}</p>
                </div>
                <div className="flex gap-1">
                  {weekDays.map((day, dayIndex) => {
                    // Find log for this habit and day
                    const log = habitLogs.find((l: any) => 
                      format(new Date(l.date), 'yyyy-MM-dd') === format(day.date, 'yyyy-MM-dd')
                    );
                    
                    // Determine if this day is applicable based on habit frequency
                    const isApplicable = 
                      habit.frequencyType === 'daily' ||
                      (habit.frequencyType === 'weekdays' && dayIndex < 5) ||
                      (habit.frequencyType === 'weekends' && dayIndex >= 5) ||
                      (habit.frequencyType === 'custom' && habit.customDays?.includes(format(day.date, 'EEEE').toLowerCase()));
                    
                    // In the future, but applicable
                    if (!day.isPast && isApplicable) {
                      return (
                        <div key={dayIndex} className="w-6 h-6 rounded-md bg-gray-100 flex items-center justify-center text-xs text-gray-400">
                          ?
                        </div>
                      );
                    }
                    
                    // In the future, not applicable
                    if (!day.isPast && !isApplicable) {
                      return (
                        <div key={dayIndex} className="w-6 h-6 rounded-md bg-gray-100 flex items-center justify-center text-xs text-gray-400">
                          -
                        </div>
                      );
                    }
                    
                    // In the past, not applicable
                    if (!isApplicable) {
                      return (
                        <div key={dayIndex} className="w-6 h-6 rounded-md bg-gray-100 flex items-center justify-center text-xs text-gray-400">
                          -
                        </div>
                      );
                    }
                    
                    // Completed
                    if (log && log.completed) {
                      return (
                        <div key={dayIndex} className="w-6 h-6 rounded-md bg-green-500 flex items-center justify-center">
                          <Check className="h-4 w-4 text-white" />
                        </div>
                      );
                    }
                    
                    // Missed
                    if (log && !log.completed) {
                      return (
                        <div key={dayIndex} className="w-6 h-6 rounded-md bg-red-500 flex items-center justify-center">
                          <X className="h-4 w-4 text-white" />
                        </div>
                      );
                    }
                    
                    // No log, but in the past and applicable (missed)
                    return (
                      <div key={dayIndex} className="w-6 h-6 rounded-md bg-gray-100 flex items-center justify-center">
                        <X className="h-4 w-4 text-gray-400" />
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
          
          {habits && habits.length === 0 && (
            <div className="text-center py-4">
              <p className="text-gray-500">No habits to display. Create your first habit to start tracking!</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
